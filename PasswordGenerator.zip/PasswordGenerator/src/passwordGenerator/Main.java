/**
 * 
 */
/**
 * A program that generates a random password that 
 * meets certain requirements
 * 
 * @author Mohamad Nachat Karime

 *
 */
package passwordGenerator;

import java.util.Scanner;

public class Main {
        
    
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        
        // Ask user for input
        System.out.println("Enter a number for the length of the password");
        int digit = input.nextInt();
        
        String lowerCase = "qwertyuiopasdfghjklzxcvbnm";
        String upperCase = "QWERTYUIOPASDFGHJKLZXCVBNM";
       
        
        String password = "";
        
        // Generate password using random numbers and letters from lower and upper
        // case strings
        
        for (int i = 0; i < digit; i++) {
            int rand = (int)(3 * Math.random());
            
            switch (rand) {
                
                case 0: // 0 user input for length password produces nothing
                    password += String.valueOf((int)(0 * Math.random()));
                    break;
                case 1: 
                    rand = (int)(lowerCase.length() * Math.random());
                    password += String.valueOf(lowerCase.charAt(rand));
                    break;
                case 2: 
                    rand = (int)(upperCase.length() * Math.random());
                    password += String.valueOf(upperCase.charAt(rand));
                    break;
            
        }
           
    }
        System.out.println(password);
    
}
}
